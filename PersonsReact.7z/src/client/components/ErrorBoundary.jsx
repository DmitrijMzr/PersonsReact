
import React, {Component} from 'react';

export default class ErrorBoundary extends Component {  constructor(props) {
    super(props);
    this.state = { hasError: false };

    this.lastErr = null;
    this.lastInfo = null;
}

    componentDidCatch(error, info) {
        this.setState({ hasError: true });

        this.lastErr = error;
        this.lastInfo = info;
    }

    render() {
        if (this.state.hasError) {
            console.log({lastErr: this.lastErr}, {lastInfo :this.lastInfo});
            return <h1>ERROR!!!</h1>;
        }
        return this.props.children;
    }
}
