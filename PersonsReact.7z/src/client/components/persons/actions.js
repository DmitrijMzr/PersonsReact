import types from "../../action-types";


export const setArrData = (arrData) => {
    console.log('wea are setting the arr data');
    return {
        type: types.SET_ARR_DATA,
        payload: arrData
    };
};

console.log(setArrData(), 'set arr data func')
