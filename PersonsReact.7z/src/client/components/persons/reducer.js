
import types from './action-types';

const personsReducer = (state = {}, action) => {
    switch (action.type) {


        default:
            return state;
    }
};
export default personsReducer;
