
const types = Object.freeze({
    SET_ARR_DATA: 'SET_ARR_DATA'
});

export default types;
