
const types = Object.freeze({

});

export default types;