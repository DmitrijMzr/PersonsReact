
import types from './action-types';

const todoListReducer = (state = {}, action) => {
    switch (action.type) {


        default:
            return state;
    }
};
export default todoListReducer;
