const todoItems = [];

todoItems.push({index: 2, value: "Learn React JS !!!", done: false});
todoItems.push({index: 3, value: "Become a Front-End developer.", done: false});
todoItems.push({index: 1, value: "Get on course Front-End.", done: true});



export default todoItems;