
const types = Object.freeze({
    SET_AND_SAVE_PAGE: 'SET_AND_SAVE_PAGE',
    SET_PAGE: 'SET_PAGE',
    SET_USERNAME: 'SET_USERNAME',
    INIT: 'INIT',
    TOGGLE_BUTTON_SAVE: 'TOGGLE_BUTTON_SAVE',
    TOGGLE_BUTTON: 'TOGGLE_BUTTON',
    LOGIN: 'LOGIN'
});

export default types;