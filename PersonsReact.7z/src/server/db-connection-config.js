module.exports = {
    host: "localhost",
    user: "persons_todo",
    password: "1111",
    database: "person"
};